function populateFormData() {
  const urlParams = new URLSearchParams(window.location.search);
  const fields = [
    "firstName",
    "middleName",
    "lastName",
    "gender",
    "phone",
    "email",
    "address",
  ];
  //map to display professionally  
const map ={
  firstName:"First Name",
  middleName:"Middle Name",
  lastName: "Last Name",
  gender: "Gender",
  phone: "Phone",
  email: "Email",
  address: "Address",

};
  for (const field of fields) {
    node = document.getElementById("dynamic-section");
    paragraph = createParagraph(field, urlParams.get(field));
    node.appendChild(paragraph);
  }

  function createParagraph(key, value) {
    const p = document.createElement("p");
    p.innerHTML = `${map[key]} : ${value}`;
    return p;
  }
}

function isEmailAddress(email) {
  var emailPattern = /^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/;
  return email.match(emailPattern);
}

function post(path, params, method = "post") {
  
  const form = document.createElement("form");
  
  form.action = path;
  form.target = "_blank";

  for (const key in params) {
    if (params.hasOwnProperty(key)) {
      const hiddenField = document.createElement("input");
      hiddenField.type = "hidden";
      hiddenField.name = key;
      hiddenField.value = params[key];

      form.appendChild(hiddenField);
    }
  }

  document.body.appendChild(form);
  form.submit();
}
    //transfering to cv page and errors
pageName = new URL(window.location.href).pathname.split("/").pop();

if (pageName == "cv.html") {
  populateFormData();
} else {
  submitButton = document.getElementById("submit-button");

  submitButton.addEventListener("click", (e) => {
    e.preventDefault();

    const errors = [];
    const fData = {};

    firstName = document.getElementById("firstName");
    fData["firstName"] = firstName.value;

    middleName = document.getElementById("middleName");
    fData["middleName"] = middleName.value;

    lastName = document.getElementById("lastName");
    fData["lastName"] = lastName.value;

    email = document.getElementById("email");
    fData["email"] = email.value;

    phone = document.getElementById("phone");
    fData["phone"] = phone.value;

    gender = document.getElementById("gender");
    fData["gender"] = gender.value;

    address = document.getElementById("address");
    fData["address"] = address.value;

    //error code for required
    if (firstName.value.length <= 0) {
      errors.push("FirstName is Required");
    }

    if (middleName.value.length <= 0) {
      errors.push("MiddleName is Required");
    }

    if (lastName.value.length <= 0) {
      errors.push("LastName is Required");
    }

    if (phone.value.length <= 0) {
      errors.push("Phone is Required");
    }

    if (!isEmailAddress(email.value)) {
      errors.push("Email is Invalid");
    }

    errorsNode = document.getElementById("validation-errors");

    if (errors.length > 0) {
      for (const error of errors) {
        const errorNode = document.createElement("li");
        errorNode.innerHTML = `${error}`;
        errorsNode.appendChild(errorNode);
      }
    } else {
      
      post("./cv.html", fData);
    }
  });
}
